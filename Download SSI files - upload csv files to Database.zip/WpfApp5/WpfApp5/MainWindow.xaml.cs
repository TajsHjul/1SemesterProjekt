﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Net;
using System.IO.Compression;
using System.IO;
using System.Data.Odbc;

namespace WpfApp5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }

        private void DownloadUnpack_Click(object sender, RoutedEventArgs e)
        {
            //----------------------------------------------------
            //Creates target/main folder
            //Downloads .zip file containing .csv files, unpacks files and deletes unwanted files. Then deletes .zip folder.
            //Creates tables in SQL-Database based on .csv files (if non-existent)
            //Inserts .csv file into tables.
            //---------------------------------------------------

            //create main-folder.
            //If folder exists, delete folder and its contents, then re-create it.

            string mainFolder = @"c:\corona_data";
            if (Directory.Exists(mainFolder) == true)
                Directory.Delete(mainFolder, true);

            Directory.CreateDirectory(mainFolder);


            //Download Zipfile
            using (var client = new WebClient())
            {

                var url = "https://covid19.ssi.dk/overvagningsdata/download-fil-med-overvaagningdata";
                string html = client.DownloadString(url);

                var pos = html.IndexOf("https://files.ssi.dk/covid19/overvagning/data/data-epidemiologiske-rapport");
                var endpos = html.IndexOf('"', pos);
                string link = html.Substring(pos, endpos - pos);

                var decodedLink = WebUtility.HtmlDecode(link);
                string resource = decodedLink;


                MessageBox.Show(resource);
                client.DownloadFile(new Uri(resource), @"c:\corona_data\NyesteCoronadata.zip");

            }

            //Unpack .zip folder into new folder, then delete .zip folder.
            string zipPath = @"c:\corona_data\NyesteCoronadata.zip";
            string extractPath = @"c:\corona_data\NyesteCoronaTal";

            ZipFile.ExtractToDirectory(zipPath, extractPath);
            File.Delete(zipPath);

            //Delete specific unwanted .csv file(s) in mainFolder by name
            deleteFileByName("Cases_by_sex.csv");
            deleteFileByName("Deaths_over_time.csv");
            deleteFileByName("Municipality_cases_time_series.csv");
            deleteFileByName("Region_summary.csv");
            deleteFileByName("Test_pos_over_time.csv");

            MessageBox.Show("Files have been downloaded succesfully and are now ready to be uploaded to database.");
        }

        static void deleteFileByName(string fileToDelete)
        {
            string fileToDeleteDirectory = @"C:\corona_data\NyesteCoronaTal\";
            File.Delete(fileToDeleteDirectory + fileToDelete);
        }

        private void CSVtoDATABASE_Click(object sender, RoutedEventArgs e)
        {

            //upload .csv files in 'SourceFolderPath' as tables to connectionString database.
            try
            {
                //Declare Variables and provide values
                string SourceFolderPath = @"C:\corona_data\NyesteCoronaTal";
                string FileExtension = ".csv";
                string FileDelimiter = ";";
                string ColumnsDataType = "NVARCHAR(100)";
                string SchemaName = "dbo";

                string connectionString = @"Server = DATAMATIKERDATA; Database = team2; User Id = t2login; Password = t2login2234;";



                //Get files from folder
                string[] fileEntries = Directory.GetFiles(SourceFolderPath, "*" + FileExtension);
                foreach (string fileName in fileEntries)
                {

                    //Create Connection to SQL Server in which you would like to create tables and load data
                    SqlConnection SQLConnection = new SqlConnection();
                    SQLConnection.ConnectionString = connectionString;

                    //Writing Data of File Into Table
                    string TableName = "";
                    int counter = 0;
                    string line;
                    string ColumnList = "";

                    System.IO.StreamReader SourceFile =
                    new System.IO.StreamReader(fileName);

                    SQLConnection.Open();
                    while ((line = SourceFile.ReadLine()) != null)
                    {
                        if (counter == 0)
                        {

                            //Read the header and prepare Create Table Statement
                            ColumnList = "[" + line.Replace(FileDelimiter, "],[") + "]";
                            TableName = (((fileName.Replace(SourceFolderPath, "")).Replace(FileExtension, "")).Replace("\\", ""));
                            string CreateTableStatement = "IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[" + SchemaName + "].";
                            CreateTableStatement += "[" + TableName + "]')";
                            CreateTableStatement += " AND type in (N'U'))DROP TABLE [" + SchemaName + "].";
                            CreateTableStatement += "[" + TableName + "]  Create Table " + SchemaName + ".[" + TableName + "]";
                            CreateTableStatement += "([" + line.Replace(FileDelimiter, "] " + ColumnsDataType + ",[") + "] " + ColumnsDataType + ")";
                            SqlCommand CreateTableCmd = new SqlCommand(CreateTableStatement, SQLConnection);
                            CreateTableCmd.ExecuteNonQuery();

                        }
                        else
                        {

                            //Prepare Insert Statement and execute to insert data
                            string query = "Insert into " + SchemaName + ".[" + TableName + "] (" + ColumnList + ") ";
                            query += "VALUES('" + line.Replace(FileDelimiter, "','") + "')";

                            SqlCommand SQLCmd = new SqlCommand(query, SQLConnection);
                            SQLCmd.ExecuteNonQuery();
                        }

                        counter++;
                    }

                    SourceFile.Close();
                    SQLConnection.Close();
                }

                MessageBox.Show(".csv files have been uploaded to database succesfully.");
            }
            catch (Exception exception)
            {
                MessageBox.Show("test" + exception);
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Configuration;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;

namespace TextBox_1semesterProjekt
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }



        private void Button_Click(object sender, RoutedEventArgs e)

        {

            string result = DateTime.Today.AddDays(-1).ToString("dd-MM-yyyy");

            Console.WriteLine(result);


            string sql = null;
            SqlCommand command;

            SqlConnection connection = new SqlConnection(@"Server = DATAMATIKERDATA; Database = team2; User Id = t2login; Password = t2login2234;");
            command = new SqlCommand(sql, connection);

            try
            {
                connection.Open();
                command.Connection = connection;

                //MUNCIPALITY
                command.CommandText = "SELECT muncipality_name FROM dbo.Muncipality";

                List<string> ByNavne = new List<string>();
                String ByNavneWithNewLineConstants = "";

                using (SqlDataReader reader = command.ExecuteReader())

                {
                    while (reader.Read())

                    {
                        //MUNCIPALITY
                        ByNavne.Add(reader[0].ToString());
                        // NewData.Text = reader["muncipality_name"].ToString();
                    }

                    foreach (string bynavn in ByNavne)
                    {
                        ByNavneWithNewLineConstants = (ByNavneWithNewLineConstants + bynavn + "\n");
                    }

                    NewData.Text = ByNavneWithNewLineConstants;
                    reader.Close();

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open) connection.Close();
            }

        }
    }
}



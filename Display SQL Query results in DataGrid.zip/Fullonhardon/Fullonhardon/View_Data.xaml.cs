﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;


namespace Fullonhardon
{
    /// <summary>
    /// Interaction logic for View_Data.xaml
    /// </summary>
    public partial class View_Data : UserControl
    {
        public View_Data()
        {
            InitializeComponent();

            //Display date above DataGrid's
            string date_Today = DateTime.Today.ToString("dd-MM-yyyy");
            string date_Yesterday = DateTime.Today.AddDays(-1).ToString("dd-MM-yyyy");

            Textblock_TodaysDate.Text = date_Today;
            Textblock_YesterdaysDate.Text = date_Yesterday;
        }

        private void UpdateData_Click(object sender, RoutedEventArgs e)
        {
            //ConnectionString and sqlQuery
            string connectionString = (@"Server = DATAMATIKERDATA; Database = team2; User Id = t2login; Password = t2login2234;");
            string sqlQuery = "SELECT * FROM dbo.Municipality";

            SqlConnection connection = new SqlConnection(connectionString);


            try
            {
                //Create DataTable and populate it with sqlQuery results
                DataTable dt_new = new DataTable();
                using (connection)
                {
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, connection))
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(dt_new);
                        }
                    }
                }

                //Set DataGrad to display DataTable
                DataGrid_NewData.ItemsSource = dt_new.DefaultView;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open) connection.Close();
            }

        }
    }
}
